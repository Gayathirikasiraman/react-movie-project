export const Footer = () => {
  return <div className="container">
    <footer className="py-3 my-5 border-top">
      <p className="text-center text-body-center">&copy; 2025 MovieHunt, Inc</p>
    </footer>
  </div>;
};
